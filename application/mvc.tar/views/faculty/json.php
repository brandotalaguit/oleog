<?php 
	$this->output->set_content_type('application/json'); 
	$this->output->set_output($json);
?>