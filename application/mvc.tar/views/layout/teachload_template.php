<?php $this->load->view('layout/header'); ?>
<?php $this->load->view($content);?>
<?php $this->load->view('layout/footer');?>


