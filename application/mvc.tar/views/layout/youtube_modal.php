<!--Modal Help -->
<div id="youtubeprocedure" class="modal fade bs-example-modal-lg" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
          <h3>ONLINE ENCODING OF GRADES - PROCEDURES</h3>
      </div>
      <div class="modal-body">
       <div class="row">
         <div class="col-md-12">
              <div class="responsive-video">
                  <div class="embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/43FonNXZE6I"></iframe>
                  </div>
              </div>
        </div>
       </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
     
      </div>
       
    </div>
  </div>
</div>