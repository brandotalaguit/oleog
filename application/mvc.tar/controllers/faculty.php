<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Faculty extends Admin_Controller {

	public function __construct()
	{
		parent::__construct();
		$models = array('schedule_m', 'student_schedule_m', 'studgrade_m', 'studgrade_trans_m');
		$this->load->model($models);
	}

	public function index()
	{
		// $this->output->enable_profiler(TRUE);

		$this->data['date_now'] = date('Y-m-d');
		$this->data['grad_date_start'] = '2016-03-07';
		$this->data['grad_date_end'] = '2016-03-07';   

		$faculty_id = $this->session->userdata('faculty_id');
		$sy_id = $this->session->userdata('sy_id');
		$sem_id = $this->session->userdata('sem_id');

		if ($this->session->userdata('IsCollege') == TRUE) 
		{
			$this->data['teach_load'] = $this->schedule_m->get_teacher_program($faculty_id, $sy_id, $sem_id);
			$this->data['teach_load_hsu'] = array();
		}
		else 
		{
			$this->data['teach_load'] = array();
			$this->data['teach_load_hsu'] = $this->session->userdata('teach_load_hsu');
		}
		
		$this->user_m->logs('View Teaching Load Page');
		
		parent::load_view('faculty/teach_load');
	}

	public function test($uri)
	{
		$grade = (float) $this->uri->segment(3, 0);
		$sched_id = (int) $this->uri->segment(4, 0);
		// dump(round($grade, 0, PHP_ROUND_HALF_DOWN));
		dump(round($grade, 1, PHP_ROUND_HALF_DOWN));

		dump('Sched Id => ' . $sched_id);
		dump($this->schedule_m->in_tp($sched_id));
	}


}

/* End of file faculty.php */
/* Location: ./application/controllers/faculty.php */
