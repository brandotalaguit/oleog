<?php
/**
* Filename: user_m.php
* Author: Brando Talaguit (ITC Developer)
*/
class User_M extends MY_Model
{
	protected $table_name = "tblfacultydisplay";
	protected $primary_key = "faculty_id";
	protected $order_by = "Lastname, Firstname, Middlename";

	public $rules = array(
		'username' => array('field' => 'username', 'label' => 'Username', 'rules' => 'trim|required|min_length[3]|max_length[50]|xss_clean'),
		'password' => array('field' => 'password', 'label' => 'Password', 'rules' => 'trim|required|min_length[3]|max_length[150]')
	);

	public $rules_admin = array(
		'LastName' => array('field' => 'LastName', 'label' => 'LastName', 'rules' => 'trim|required|callback__unique_name|xss_clean'),
		'FirstName' => array('field' => 'FirstName', 'label' => 'FirstName', 'rules' => 'trim|required|xss_clean'),
		'MiddleName' => array('field' => 'MiddleName', 'label' => 'MiddleName', 'rules' => 'trim|required|xss_clean'),
		'Birthday' => array('field' => 'Birthday', 'label' => 'Birthday', 'rules' => 'trim|required|date|xss_clean'),
		'Username' => array('field' => 'Username', 'label' => 'Username', 'rules' => 'trim|required|max_length[20]|xss_clean'),
		'Password' => array('field' => 'Password', 'label' => 'Password', 'rules' => 'trim|matches[ConfirmPassword]'),
		'ConfirmPassword' => array('field' => 'ConfirmPassword', 'label' => 'ConfirmPassword', 'rules' => 'trim|matches[Password]'),
		'EmailAddress' => array('field' => 'EmailAddress', 'label' => 'Email', 'rules' => 'trim|required|valid_email'),
		'AccountType' => array('field' => 'AccountType', 'label' => 'Account Type', 'rules' => 'trim|required|xss_clean'),
	);

	function __construct()
	{
		parent::__construct();
		$this->load->model('schedule_m');
		$this->load->model('schedule_hsu_m');
	}


	public function login()
	{
		$SyId = $this->session->userdata('sy_id');
		$SemId = $this->session->userdata('sem_id');

		$condition = array(
			'username' => $this->input->post('username'),
			'password' => $this->hash($this->input->post('password'))
		);

		if (ENVIRONMENT == 'development') unset($condition['password']);
		$user = $this->get_by($condition, TRUE);

		if (count($user))
		{
			# Log in user
			$data = array(
				'lastname' => $user->Lastname,
				'firstname' => $user->Firstname,
				'middlename' => $user->Middlename,
				'username' => $user->username,
				'faculty_id' => $user->faculty_id,
				'IsCollege' => TRUE,
				'loggedin' => TRUE
			);

			$teach_load = $this->schedule_m->get_teacher_program($user->faculty_id, $SyId, $SemId);

			
			$this->session->set_userdata(array('teach_load' => $teach_load, 'teach_load_hsu' => array()));
			$this->session->set_userdata($data);

			if (ENVIRONMENT == 'development') 
			{
				if (count($teach_load)) 
				{
					$this->logs('Logged In');
					return TRUE;
				}
			}
			else 
			{
				return TRUE;
			}

		}


		$condition2 = array(
			'username' => $this->input->post('username'),
			'password2' => $this->hash($this->input->post('password'))
		);

		if (ENVIRONMENT == 'development') unset($condition2['password2']);
		$user2 = $this->get_by($condition2, TRUE);

		if (count($user2))
		{
			# Log in user
			$data = array(
				'lastname' => $user2->Lastname,
				'firstname' => $user2->Firstname,
				'middlename' => $user2->Middlename,
				'username' => $user2->username,
				'faculty_id' => $user2->faculty_id,
				'IsCollege' => FALSE,
				'loggedin' => TRUE
			);

			// Teaching Load HSU
			$this->db->where(array(HSU_DB . '.schedules.SyId' => $SyId, HSU_DB . '.schedules.SemId' => $SemId));
			$this->db->where(HSU_DB . '.schedules.prof_id', $user2->faculty_id);
			$teach_load_hsu = $this->schedule_hsu_m->get();

			$this->logs('Logged In');
			$this->session->set_userdata(array('teach_load' => array(), 'teach_load_hsu' => $teach_load_hsu));
			$this->session->set_userdata($data);
			return TRUE;
		}

		// If we get to here then login did not succeed
		return FALSE;
	}

	public function loggedin()
	{
		return (bool) $this->session->userdata('loggedin');
	}

	public function logout()
	{
		$this->logs('Logged Out');
		$this->session->sess_destroy();
	}

	public function admin_login()
	{
		$condition = array(
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password')),
			'is_actived' => 1,
		);

		if (ENVIRONMENT == 'development') unset($condition['password']);
		$this->db->where_in('user_type', array('S', 'R'));
		$user = $this->db->get_where('tbluser', $condition)->row();
		if (count($user))
		{
			# Log in user
			$data = array(
				'lastname' => $user->lastname,
				'firstname' => $user->firstname,
				'middlename' => $user->middlename,
				'username' => $user->username,
				'Id' => $user->Id,
				'IsCollege' => FALSE,
				'loggedin' => TRUE
			);

			$this->session->set_userdata($data);
			$this->admin_logs("Admin Logged In");
		}

		// If we get to here then login did not succeed
		return FALSE;
	}

	public function get_new()
	{
		$user = new stdClass();
		$user->lastname = '';
		$user->firstname = '';
		$user->middlename = '';
		$user->username = '';
		$user->password = '';
		$user->accounttype = '';

		return $user;
	}

	public function hash($string)
	{
		return hash('md5', $string . config_item('encryption_key'));
	}

	public function logs($action)
	{
		$log_transaction = array(
			'faculty_id' => $this->session->userdata('faculty_id'), 
			'action' => $action, 
			'created_at' => date('Y-m-d H:i:s'), 
			'updated_at' => date('Y-m-d H:i:s')
		);

		$this->db->insert('tbleoglogs', $log_transaction);
		$this->db->close();
	}

	public function admin_logs($action)
	{
		$log_transaction = array(
			'faculty_id' => $this->session->userdata('Id'), 
			'action' => $action, 
			'created_at' => date('Y-m-d H:i:s'), 
			'updated_at' => date('Y-m-d H:i:s')
		);

		$this->db->insert('tbleoglogs', $log_transaction);
		$this->db->close();
	}

	public function admin_logout()
	{
		$this->admin_logs("Admin Logged Out");
		$this->session->sess_destroy();
	}

	public function get_faculty()
	{
		// Fetch employees
		$this->db->select('username, Lastname, Firstname, Middlename');
		$employees = parent::get();

		// Return key -> value pair array
		$array = array('0' => 'Select faculty');
		if (count($employees)) 
		{
			foreach ($employees as $employee) 
			{
				$array[$employee->username] = $employee->Lastname . ', ' . $employee->Firstname . ' ' . $employee->Middlename;
				// $array[$employee->employee_id] = $employee->member_status;
			}
		}
		return $array;
	}

}

/*Location: ./application/models/user_m.php*/
